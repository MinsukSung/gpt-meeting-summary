package com.gpt.meetingnotes.common.validation;

public interface ValidationGroups {
	interface Analyze {}
}
