package com.gpt.meetingnotes.gpt.client;

public class GptHttpClient {

}
