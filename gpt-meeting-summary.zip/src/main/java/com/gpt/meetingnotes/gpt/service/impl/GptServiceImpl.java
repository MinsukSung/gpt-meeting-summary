package com.gpt.meetingnotes.gpt.service.impl;

import org.springframework.stereotype.Service;

import com.gpt.meetingnotes.gpt.service.GptService;

@Service
public class GptServiceImpl implements GptService {

}
