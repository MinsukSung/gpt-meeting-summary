package com.gpt.meetingnotes.gpt.service;

public interface GptService {

}
